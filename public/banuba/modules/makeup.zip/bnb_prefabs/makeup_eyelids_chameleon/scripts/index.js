const { Base } = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion } = require("bnb_prefabs/makeup_base/scripts/index.js")

const settings = JSON.parse(require("./settings.js"))

const default_threshold = 0.92;
const default_contour = 0.3;
const default_weakness = 0.25;

const layers_names = ["_blur_hsv_layer", "_mean_layer", "_stddev_layer", "_tone_layer"];
const max_colors_amount = 3;

class MakeupEyelidsChameleon extends Base {
    constructor(faceIndex=0) {
        super(faceIndex);
        
        /* bottom colors */
        this.regions0 = [
            new FaceRegion("eyelids_chameleon_00", settings),
            new FaceRegion("eyelids_chameleon_01", settings),
            new FaceRegion("eyelids_chameleon_02", settings),
        ]
        
        /* top colors */
        this.regions1 = [
            new FaceRegion("eyelids_chameleon_10", settings),
            new FaceRegion("eyelids_chameleon_11", settings),
            new FaceRegion("eyelids_chameleon_12", settings),
        ]
        
        this.params = new bnb.FeatureParameter(default_threshold, default_contour, default_weakness);
        
        /* store all layers to disable unused */
        this.bottomLayers = [];
        this.upperLayers = [];
        for (let i = 0; i < max_colors_amount; i++) {
            for (let j = 0; j < layers_names.length; j++) {
                let bottomLayerName = "eyelids_chameleon_0" + i.toString() + layers_names[j];
                let bottomLayer = bnb.scene.getLayer(bottomLayerName);
                this.bottomLayers.push(bottomLayer);
                
                let upperLayerName = "eyelids_chameleon_1" + i.toString() + layers_names[j];
                let upperLayer = bnb.scene.getLayer(upperLayerName);
                this.upperLayers.push(upperLayer);
            }
        }
    }

    setPrefabSettings(state) {
        this.clear();
        
        if (state.colors['bottom'].length > max_colors_amount || state.colors['upper'].length > max_colors_amount) {
            bnb.log(`[WARN] Colors amount exceeded!`);
        }
        
        for (const [i, s] of state.colors['bottom'].entries()) {
            if (i > this.regions0.length) break
            MakeupBase.apply(this.regions0[i], s)
        }
        
        for (const [i, s] of state.colors['upper'].entries()) {
            if (i > this.regions1.length) break
            MakeupBase.apply(this.regions1[i], s)
        }
        
        /* set chameleon mask params */
        this.threshold(state.threshold);
        this.contour(state.contour);
        this.weakness(state.weakness);
        
        /* disable unused layers */
        this.setLayersActive(state.colors['bottom'].length, state.colors['upper'].length);
    }
    
    threshold(value) {
        this.params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
    }
    
    contour(value) {
        this.params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
    }
    
    weakness(value) {
        this.params.z = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
    }
    
    setLayersActive(bottomAmount, upperAmount) {
        for (let i = 0; i < max_colors_amount * layers_names.length; i++) {
            this.bottomLayers[i].setActive(i < bottomAmount * layers_names.length);
            this.upperLayers[i].setActive(i < upperAmount * layers_names.length);
        }
    }

    clear() {
        for (const region of this.regions0) region.clear()
        for (const region of this.regions1) region.clear()

        this.params.x = default_threshold;
        this.params.y = default_contour;
        this.params.z = default_weakness;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
        
        this.setLayersActive(0, 0);
    }
}

exports = {
    MakeupEyelidsChameleon
}
