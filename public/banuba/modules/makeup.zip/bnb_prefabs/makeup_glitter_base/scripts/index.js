const prefabs = require("bnb_js/prefabs")

class MakeupGlitterBase extends prefabs.Base {
    constructor(faceIndex = 0) {
        if (faceIndex !== 0) {
            throw Error(`MakeupGlitterBase prefab support only face index 0, got ${faceIndex}`);
        }
        super(faceIndex);
    }

    clear() {
    }
}

exports = {
    MakeupGlitterBase
}

