'use strict';

const prefabs = require("bnb_js/prefabs");
const { MakeupBase, FaceRegion } = require("bnb_prefabs/makeup_base/scripts/index.js")

const default_threshold = 0.98;
const default_contour = 0.5;
const default_weakness = 0.5;
const default_multiplier = 1.5;
const default_alpha = 0.6;

class MakeupEyelidsgloss extends prefabs.Base {
    constructor(faceIndex=0) {
        super(faceIndex);

        this.params = new bnb.FeatureParameter(default_threshold, default_contour, default_weakness, 0.0);

        const assets = bnb.scene.getAssetManager();
        this.material = assets.findMaterial("shaders/eyelids_gloss");
        this.max_brightness_param = this.material.findParameter("eyelids_gloss_max_brightness");
        this.multiplier_alpha_param = this.material.findParameter("eyelids_gloss_multiplier_alpha");

        this.multiplier_value = default_multiplier;
        this.alpha_value = default_alpha;

        bnb.eventListener.on("onLateUpdate", (fd)=> {
            const max_brightness = fd.getEyelidsGlossMaxBrightness();
            this.max_brightness_param.setVector4(new bnb.Vec4(max_brightness, 0.0, 0.0, 0.0));
        });
    }
    
    threshold(value) {
        this.params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params]);
    }
    
    contour(value) {
        this.params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params]);
    }
    
    weakness(value) {
        this.params.z = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params]);
    }

    multiplier(value) {
        this.multiplier_value = value;
        this.multiplier_alpha_param.setVector4(new bnb.Vec4(this.multiplier_value, this.alpha_value, 0.0, 0.0));
    }
    
    alpha(value) {
        this.alpha_value = value;
        this.multiplier_alpha_param.setVector4(new bnb.Vec4(this.multiplier_value, this.alpha_value, 0.0, 0.0));
    }
    
    clear() {
        this.max_brightness_param.setVector4(new bnb.Vec4(0.0, 0.0, 0.0, 0.0));
        this.multiplier(default_multiplier);
        this.alpha(default_alpha);
        
        this.params.x = default_threshold;
        this.params.y = default_contour;
        this.params.z = default_weakness;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params]);
    }
}

exports = {
    MakeupEyelidsgloss
}
