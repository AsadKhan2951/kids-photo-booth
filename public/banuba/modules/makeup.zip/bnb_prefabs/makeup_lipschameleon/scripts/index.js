const { Base } = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion } = require("bnb_prefabs/makeup_base/scripts/index.js")

const settings = JSON.parse(require("./settings.js"))

const default_threshold = 0.92;
const default_contour = 0.3;
const default_weakness = 0.25;

class MakeupLipschameleon extends Base {
    constructor(faceIndex=0) {
        super(faceIndex);
        
        this.region0 = new FaceRegion("lipschameleon_0", settings);
        this.region1 = new FaceRegion("lipschameleon_1", settings);
        
        this.params = new bnb.FeatureParameter(default_threshold, default_contour, default_weakness);
    }

    setPrefabSettings(state) {
        this.clear();
        MakeupBase.apply(this.region0, state.colors[0]);
        MakeupBase.apply(this.region1, state.colors[1]);
        bnb.scene.enableRecognizerFeature(bnb.FeatureID.LIPS_CORRECTION);
        
        this.threshold(state.threshold);
        this.contour(state.contour);
        this.weakness(state.weakness);
    }
    
    threshold(value) {
        this.params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_CHAMELEON, [this.params]);
    }
    
    contour(value) {
        this.params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_CHAMELEON, [this.params]);
    }
    
    weakness(value) {
        this.params.z = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_CHAMELEON, [this.params]);
    }

    clear() {
        bnb.scene.disableRecognizerFeature(bnb.FeatureID.LIPS_CORRECTION);
        this.region0.clear();
        this.region1.clear();

        this.params.x = default_threshold;
        this.params.y = default_contour;
        this.params.z = default_weakness;
        bnb.scene.addFeatureParam(bnb.FeatureID.LIPS_CHAMELEON, [this.params]);
    }
}

exports = {
    MakeupLipschameleon
}
