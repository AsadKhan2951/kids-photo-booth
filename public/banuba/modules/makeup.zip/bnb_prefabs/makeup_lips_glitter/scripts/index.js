const prefabs = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion, FaceRegionBase } = require("bnb_prefabs/makeup_base/scripts/index.js")

class MakeupLipsGlitter extends prefabs.Base {
    constructor(faceIndex = 0) {
        super(faceIndex);

        this.region = new FaceRegionBase("lips_glitter", ["lips_nn"])

        this.cached_glitter_color_alpha = new bnb.Vec4(0, 0, 0, 0);

        const glitter_mat = bnb.scene.getAssetManager().findMaterial("lips_glitter_mat");
        this.glitter_color_alpha_param = glitter_mat.findParameter("lips_glitter_color_alpha");
    }

    color(value) {
        const _value = prefabs.parseColor(value);
        this.cached_glitter_color_alpha.x = _value.x;
        this.cached_glitter_color_alpha.y = _value.y;
        this.cached_glitter_color_alpha.z = _value.z;

        this.glitter_color_alpha_param.setVector4(this.cached_glitter_color_alpha);
    }

    alpha(value) {
        const _value = Math.min(Math.max(value, 0.0), 1.0);
        this.cached_glitter_color_alpha.w = _value;

        this.glitter_color_alpha_param.setVector4(this.cached_glitter_color_alpha);

        if (_value > 0.0)
          this.region._show();
        else
          this.region._hide();
    }

    clear() {
        this.glitter_color_alpha_param.setVector4(prefabs.parseColor("0 0 0 0"));
        this.region._hide();
    }
}

exports = {
    MakeupLipsGlitter
}
