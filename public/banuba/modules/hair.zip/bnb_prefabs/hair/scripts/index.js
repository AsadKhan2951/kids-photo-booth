const prefabs = require("bnb_js/prefabs");

var ColoringMode;
(function (ColoringMode) {
    /* 0 */ ColoringMode[ColoringMode["SolidColor"] = 0] = "SolidColor";
    /* 1 */ ColoringMode[ColoringMode["Gradient"] = 1] = "Gradient";
})(ColoringMode || (ColoringMode = {}));

class Hair extends prefabs.Base {
    constructor(faceIndex=0) {
        super();
        
        /* solid and gradient colors params */
        const mat = bnb.scene.getAssetManager().findMaterial("shaders/hair/hair");
        this._colors = [];
        for (let i = 0; i < 5; ++i) {
            const param = mat.findParameter(`var_hair_color${i}`);
            param && this._colors.push(param);
        }

        /* solid/gradient mode */
        this._mode = mat.findParameter("var_hair_colors_count_mode");
    }

    color(first, ...rest) {
        if (Array.isArray(first))
            return this.color(...first);

        const colors = [first, ...rest];
        this._mode.setX(colors.length);
        this._mode.setY(colors.length === 1 ? ColoringMode.SolidColor : ColoringMode.Gradient);

        for (let i = 0; i < colors.length; ++i)
            this._colors[i].setVector4(prefabs.parseColor(colors[i] ?? "0 0 0"));
        
        return colors;
    }

    clear() {
        this._mode.setX(1);
        this._mode.setY(ColoringMode.SolidColor);

        for (let i = 0; i < 5; ++i) {
            this._colors[i].setVector4(prefabs.parseColor("0 0 0"));
        }
    }
}

exports = {
    Hair
}
